"""V7 加厚／放寬試裝版。單位 mm，X 朝前 Y 朝左 Z 朝上。"""
from pathlib import Path
import cadquery as cq
import math,json,base64,struct,hashlib
from collections import Counter
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
R=Path(__file__).resolve().parent
for sub in ['STL_列印','STEP_可修改','SKP_模型','試配小件','qa','web']:(R/sub).mkdir(exist_ok=True)
P=dict(barrel_d=31.,flange_d=36.,flange_relief_d=37.2,lens_length=35.,lens_mass_g=66.011,ring_id=32.2,ring_wall=3.2,ring_length=14.,slit=2.,ear_thickness=4.,m3_hole=3.6,liner_per_side=.4,pad_length=38.,pad_width=24.,pad_centres=46.,pad_t=3.2,beam_t=4.,beam_width=10.,front_gap=4.,qr_plate_length=42.,qr_plate_width=44.,qr_plate_min_t=3.2,qr_saddle_r=150.,finger_t=4.,finger_gap=4.6,m5_hole=5.5,hinge_z=15.)
(R/'設計參數.json').write_text(json.dumps(P,ensure_ascii=False,indent=2),encoding='utf-8')
RI=P['ring_id']/2;RO=RI+P['ring_wall'];RL=P['ring_length'];HINGE=P['hinge_z'];FR=8.5;PITCH=P['finger_t']+P['finger_gap'];ZQR=HINGE+FR+2.5+RO
def bb(s):
    b=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,b,False,False);return cq.BoundBox(b)
def box(l,w,h,xyz):return cq.Workplane('XY').box(l,w,h).translate(xyz)
def xcyl(rad,x0,l,z,y=0):return cq.Workplane('YZ').workplane(offset=x0).center(y,z).circle(rad).extrude(l)
def ring(x,z):
    ears=box(RL,P['slit']+2*P['ear_thickness'],7,(x,0,z+RO+1.5)).edges('|X and >Z').fillet(1.5)
    return xcyl(RO,x-RL/2,RL,z).union(ears)
def ringcuts(b,x,z):
    # The larger shoulder lies just behind the ring. Relieve beam / claw roots,
    # leaving the Ø31 barrel grip surface unchanged.
    b=b.cut(xcyl(P['flange_relief_d']/2,x-RL/2-7,7,z))
    b=b.cut(xcyl(RI,x-RL/2-1,RL+2,z))
    b=b.cut(box(RL+2,P['slit'],RO+10,(x,0,z+RI-3+(RO+10)/2)))
    return b.cut(cq.Workplane('XZ').workplane(offset=-30).center(x,z+RO+2).circle(P['m3_hole']/2).extrude(60)).clean()
def lens(x,z):return xcyl(18,x-RL/2-6.5,6.5,z).union(xcyl(15.5,x-RL/2,28.5,z))
def beam(a,b):
    a=cq.Vector(*a);b=cq.Vector(*b);d=b-a;axis=cq.Vector(0,0,1).cross(d)
    q=box(P['beam_width'],P['beam_t'],d.Length+2,(0,0,0))
    if axis.Length>1e-9:q=q.rotate((0,0,0),axis.toTuple(),math.degrees(math.acos(d.z/d.Length)))
    return q.translate(((a+b)*.5).toTuple())
def frontadh():
    x=100+13.5+P['front_gap']-66;z=-23;pl=P['pad_length'];py=P['pad_centres']/2;pz=1+P['pad_t']/2;out=100+P['front_gap']-66
    q=ring(x,z)
    for sign in [-1,1]:
        y=sign*py
        q=q.union(box(pl,P['pad_width'],P['pad_t'],(0,y,pz)).edges('|Z').fillet(4))
        q=q.union(beam((pl/2-4,y,pz),(out,y,pz)))
        q=q.union(beam((out,y,pz),(x-RL/2+1,sign*10,z+RO-3)))
        # Foot-to-arm web, 4 mm thick, overlaps both solids; no shell penetration.
        web=cq.Workplane('XZ').workplane(offset=-(y+2)).polyline([(pl/2-9,1),(out+2,1),(out+2,6),(pl/2-9,4.2)]).close().extrude(4)
        q=q.union(web)
    q=q.union(box(7,P['pad_centres']+P['pad_width']-8,P['pad_t'],(-pl/2+3.5,0,pz)))
    q=q.cut(cq.Workplane('XY').workplane(offset=-5).center(-pl/2+3.5,0).circle(1.8).extrude(20))
    return ringcuts(q,x,z),lens(x,z)
def glueplate():
    lx=P['qr_plate_length'];wy=P['qr_plate_width'];t=P['qr_plate_min_t'];rad=P['qr_saddle_r'];sag=rad-math.sqrt(rad*rad-(wy/2)**2)
    q=cq.Workplane('XY').box(lx,wy,t+5,centered=(True,True,False)).edges('|Z').fillet(5).translate((0,0,-sag))
    q=q.cut(xcyl(rad,-100,200,-rad)).cut(box(300,300,50,(0,0,t+25)))
    tab=cq.Workplane('XY').center(-lx/2-3,0).rect(10,12).extrude(t).edges('|Z').fillet(2.5)
    return q.union(tab).cut(cq.Workplane('XY').center(-lx/2-3.5,0).circle(1.8).extrude(15))
def finger(y,up,root):
    q=cq.Workplane('XZ').workplane(offset=-(y+P['finger_t']/2)).moveTo(-FR,root).lineTo(FR,root).lineTo(FR,HINGE)
    return q.threePointArc((0,HINGE+(FR if up else -FR)),(-FR,HINGE)).close().extrude(P['finger_t'])
def hinge_hole():return cq.Workplane('XZ').workplane(offset=-40).center(0,HINGE).circle(P['m5_hole']/2).extrude(80)
def qr():
    base=glueplate()
    for y in [-PITCH,0,PITCH]:base=base.union(finger(y,True,P['qr_plate_min_t']-.2))
    base=base.union(box(18,3*P['finger_t']+2*P['finger_gap']+2,2.2,(0,0,4.1)))
    for y in [-PITCH/2,PITCH/2]:base=base.cut(box(22,P['finger_gap'],40,(0,y,25.4)))
    base=base.cut(hinge_hole()).clean()
    bot=ZQR-RO;rr=ring(0,ZQR)
    for y in [-PITCH/2,PITCH/2]:rr=rr.union(finger(y,False,bot+2))
    rr=rr.union(box(14,2*P['finger_t']+P['finger_gap'],4,(0,0,bot+1.5)))
    rr=rr.cut(box(22,P['finger_gap'],6,(0,0,HINGE+2)))
    return base,ringcuts(rr,0,ZQR).cut(hinge_hole()).clean(),lens(0,ZQR)
def meshcheck(data):
    n=struct.unpack_from('<I',data,80)[0];assert len(data)==84+50*n
    e=Counter();d=Counter();verts=[];vol=0
    for i in range(n):
        t=struct.unpack_from('<12fH',data,84+50*i);v=[tuple(t[k:k+3]) for k in (3,6,9)];verts.extend(v);a,b,c=v
        vol+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
        for j in range(3):u,w=v[j],v[(j+1)%3];e[tuple(sorted((u,w)))]+=1;d[(u,w)]+=1
    assert all(v==2 for v in e.values());assert all(d[(w,u)]==v for (u,w),v in d.items());assert vol>0
    return dict(watertight=True,consistent_winding=True,triangles=n,volume_mm3=vol,min_z=min(p[2] for p in verts),size_mm=[max(p[k] for p in verts)-min(p[k] for p in verts) for k in range(3)])
def area(l,w,r):return l*w-(4-math.pi)*r*r
def main():
    adh,la=frontadh();base,rr,lq=qr();parts={'evo_front_adh':adh,'qr_base':base,'qr_ring':rr}
    data=dict(status='V7 加厚放寬試裝版；局部曲面未量測',units='mm',date='2026-10-08',params=P,parts={})
    models={};prints={};views={'front':(1,0,0),'side':(0,-1,0),'top':(0,0,1),'iso':(1.2,-1.4,1)}
    for k,q in parts.items():
        s=q.val();assert s.isValid() and q.solids().size()==1,(k,'BREP',q.solids().size());b=bb(s)
        path=R/'STEP_可修改'/f'{k}.step';cq.exporters.export(q,str(path));back=cq.importers.importStep(str(path));assert back.val().isValid() and abs(back.val().Volume()-s.Volume())<.01
        # Stand up rings so circumferential loads are carried chiefly within layers.
        placed=q.rotate((0,0,0),(0,1,0),-90) if k!='qr_base' else q
        placed=placed.translate((0,0,-bb(placed.val()).zmin));path=R/'STL_列印'/f'{k}.stl';cq.exporters.export(placed,str(path),tolerance=.025,angularTolerance=.12)
        m=meshcheck(path.read_bytes());assert m['min_z']>=-1e-4;assert abs(m['volume_mm3']/s.Volume()-1)<.005
        prints['v7_'+k]=base64.b64encode(path.read_bytes()).decode()
        wp=R/'web'/f'{k}.stl';cq.exporters.export(q,str(wp),tolerance=.04,angularTolerance=.14);models['v7_'+k]=base64.b64encode(wp.read_bytes()).decode();meshcheck(wp.read_bytes())
        data['parts'][k]=dict(bbox_design_mm=[b.xlen,b.ylen,b.zlen],bounds=[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax],volume_cm3=s.Volume()/1000,petg_solid_g=s.Volume()/1000*1.27,stl_check=m,step_roundtrip_valid=True)
        for view,proj in views.items():(R/'qa'/f'{k}_{view}.svg').write_text(cq.exporters.getSVG(s,dict(projectionDir=proj,showHidden=False,showAxes=False,width=500,height=300,strokeWidth=.4)),encoding='utf-8')
    for k,q in [('adh_lens',la),('qr_lens',lq)]:
        path=R/'web'/f'{k}.stl';cq.exporters.export(q,str(path),tolerance=.04,angularTolerance=.14);models['v7_'+k]=base64.b64encode(path.read_bytes()).decode()
    checks=[]
    for angle in range(-30,31,5):
        rotated=rr.rotate((0,0,HINGE),(0,1,HINGE),-angle)
        iv=sum(s.Volume() for s in base.intersect(rotated).solids().vals());checks.append([angle,iv]);assert iv<.01,(angle,'hinge collision',iv)
    data['hinge']=dict(axis_z=HINGE,lens_axis_z=ZQR,side_clearance_mm=.3,own_pair_interface=True,pitch_checks=checks)
    collisions={'front_lens_mm3':sum(s.Volume() for s in adh.intersect(la).solids().vals()),'qr_ring_lens_mm3':sum(s.Volume() for s in rr.intersect(lq).solids().vals()),'qr_base_lens_mm3':sum(s.Volume() for s in base.intersect(lq).solids().vals())}
    assert all(v<.01 for v in collisions.values()),collisions
    data['lens_assembly_collisions']=collisions
    data['adhesion']=dict(front_projected_mm2=2*area(P['pad_length'],P['pad_width'],4),front_old_projected_mm2=2*area(26,18,3),qr_projected_mm2=area(P['qr_plate_length'],P['qr_plate_width'],5),qr_old_projected_mm2=area(26,28,5),note='投影幾何面積，未計膠帶裁切與孔洞；不是有效黏著面積或承載核定')
    for name,q in [('T1_ID32p2_套環5mm',rr.intersect(box(5,100,100,(0,0,ZQR+20)))),('T2_三爪',base.intersect(box(20,24,23,(0,0,15)))),('T3_二爪',rr.intersect(box(20,24,27,(0,0,20))))]:
        assert q.val().isValid() and q.solids().size()==1,(name,q.solids().size());placed=q.rotate((0,0,0),(0,1,0),-90);placed=placed.translate((0,0,-bb(placed.val()).zmin));path=R/'試配小件'/f'{name}.stl';cq.exporters.export(placed,str(path),tolerance=.025,angularTolerance=.12);meshcheck(path.read_bytes())
    # 1-mm thin footprint templates, not load carrying pieces, to check contact extent.
    for name,l,w,rad in [('T4_前置38x24腳座',38,24,4),('T5_快拆42x44貼面',42,44,5)]:
        q=cq.Workplane('XY').rect(l,w).extrude(1).edges('|Z').fillet(rad);cq.exporters.export(q,str(R/'試配小件'/f'{name}.stl'))
    assembly=cq.Assembly();assembly.add(base,name='QR_Base');assembly.add(rr,name='QR_Ring');assembly.save(str(R/'STEP_可修改'/'qr_assembly.step'))
    ag=data['parts']['evo_front_adh']['petg_solid_g'];qg=sum(data['parts'][k]['petg_solid_g'] for k in ['qr_base','qr_ring'])
    data['mass']=dict(base_reference_g=1187,lens_g=66.011,adh_hardware_estimate_g=3,qr_hardware_estimate_g=4,adh_total_estimate_g=1187+66.011+ag+3,qr_total_estimate_g=1187+66.011+qg+4,hardware_note='包含螺栓、螺帽、墊片及膠帶概估；需實秤')
    (R/'尺寸與幾何檢核.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    webdata=dict(models=models,print_models=prints,stats=data['parts'],params=P,report=data,config={'adh':dict(stl='v7_evo_front_adh',lens='v7_adh_lens',position=[66,0,108],rotation_x=0,lens_axis_z=85,front_gap=4,hardware_g=3,bracket_g=ag,mount_g=ag+3,pad_area_mm2=data['adhesion']['front_projected_mm2']),'qr':dict(stls=['v7_qr_base','v7_qr_ring'],lens='v7_qr_lens',hinge=HINGE,lens_axis_z=ZQR,hardware_g=4,bracket_g=qg,mount_g=qg+4)})
    (R/'mounts-v7.js').write_text('window.MOUNT_V7='+json.dumps(webdata,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
    print(json.dumps({k:dict(dims=v['bbox_design_mm'],g=v['petg_solid_g']) for k,v in data['parts'].items()}));print('hinge checks',checks);print('areas',data['adhesion'])
if __name__=='__main__':main()
