"""驗證 STL 封閉邊、方向、網頁下載內容及 CAD 體積近似一致。"""
from pathlib import Path
from collections import Counter
import struct,json,base64,math,hashlib
R=Path(__file__).resolve().parent
def check(path):
    data=path.read_bytes();n=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+50*n, (path,'binary STL size')
    edges=Counter();direct=Counter();volume=0
    for i in range(n):
        values=struct.unpack_from('<12fH',data,84+50*i);vs=[tuple(values[j:j+3]) for j in (3,6,9)]
        a,b,c=vs
        volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
        for j in range(3):
            u,v=vs[j],vs[(j+1)%3];edges[tuple(sorted((u,v)))]+=1;direct[(u,v)]+=1
    bad=sum(k!=2 for k in edges.values());orientation=sum(direct[(v,u)]!=k for (u,v),k in direct.items())
    assert not bad and not orientation,(path,'mesh edges',bad,orientation)
    assert volume>0,(path,'orientation/volume',volume)
    return {'triangles':n,'watertight_edges':True,'oriented_edges':True,'volume_cm3':volume/1000,'sha256':hashlib.sha256(data).hexdigest()}
def main():
    report=json.loads((R/'geometry_report.json').read_text(encoding='utf-8'))
    asset=(R.parent/'網頁模擬'/'mounts-v6.js').read_text(encoding='utf-8')
    web=json.loads(asset[len('window.MOUNT_V6='):-2]);results={}
    for p in sorted((R/'STL_試裝').glob('*.stl')):
        key=p.stem.removesuffix('_待量測');v=check(p)
        rel=abs(v['volume_cm3']/report['stats'][key]['volume_cm3']-1);assert rel<0.005,(key,rel)
        assert base64.b64decode(web['print_models'][key])==p.read_bytes(),(key,'download mismatch')
        v['relative_brep_volume_error']=rel;results[key]=v
    (R/'stl_check.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
