"""實機照片參考之待量測試裝支架。X 向前、Y 向左、Z 向上，mm。
只產生參數化候選模型；不得將 BREP 檢核當成實機適配或飛行認證。
執行：python generate_mounts.py；修改 params.json 後重新產製。
"""
from pathlib import Path
import math, json, base64, struct, zipfile
import cadquery as cq
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'params.json').read_text(encoding='utf-8'))
L=P['lens']; RI=(L['barrel_d']+L['clearance'])/2; RO=RI+L['wall']; RL=L['ring_length']
MODELS={}; STATS={}; CONFIG={}; PRINT={}

def bbox(s):
    # 不使用匯出 STL 後的三角網格外框，避免網格偏差改變間隙與列印原點。
    b=Bnd_Box(); BRepBndLib.AddOptimal_s(s.wrapped,b,False,False)
    return cq.BoundBox(b)

def box(l,w,h,xyz):
    return cq.Workplane('XY').box(l,w,h).translate(xyz)

def xcyl(r,x0,length,z,y=0):
    return cq.Workplane('YZ').workplane(offset=x0).center(y,z).circle(r).extrude(length)

def ring_blank(x,z):
    body=xcyl(RO,x-RL/2,RL,z)
    ears=box(RL,7.6,7,(x,0,z+RO+1.5))
    return body.union(ears)

def ring_cut(body,x,z,y=0):
    body=body.cut(xcyl(RI,x-RL/2-1,RL+2,z,y))
    body=body.cut(box(RL+2,1.6,RO+10,(x,y,z+RI-3+(RO+10)/2)))
    hole=cq.Workplane('XZ').workplane(offset=-(y+15)).center(x,z+RO+2).circle(1.7).extrude(30)
    return body.cut(hole)

def lens(x,z,y=0):
    # 後端大肩圈靠機身，前端光軸朝 +X。相同實際 35 mm 鏡筒。
    return xcyl(L['flange_d']/2,x-RL/2-6.5,6.5,z,y).union(xcyl(L['barrel_d']/2,x-RL/2,28.5,z,y))

def beam(a,b,w=8,t=2.4):
    a=cq.Vector(*a); b=cq.Vector(*b); d=b-a; length=d.Length
    body=box(w,t,length+2,(0,0,0))
    axis=cq.Vector(0,0,1).cross(d)
    angle=math.degrees(math.acos(max(-1,min(1,d.z/length))))
    if axis.Length>1e-9: body=body.rotate((0,0,0),axis.toTuple(),angle)
    elif d.z<0: body=body.rotate((0,0,0),(1,0,0),180)
    return body.translate(((a+b)*0.5).toTuple())

def rounded_section(w,h,r,cz,x0,length):
    return cq.Workplane('YZ').workplane(offset=x0).center(0,cz).rect(w,h).extrude(length).edges('|X').fillet(r)

def front(c,kind):
    n=P['nose']; w,h,r=c['nose_width'],c['nose_height'],c['nose_radius']; fit=n['fit']; t=n['strap_thickness']
    ax=c['nose_axis_z']-c['top_z']; x=c['nose_front_x']+13.5+n['front_gap']-c['nose_clamp_x']
    offset=c.get('lens_offset_y',0)
    body=ring_blank(x,ax).translate((0,offset,0))
    if kind=='nose':
        frame=rounded_section(w+2*fit+2*t,h+2*fit+2*t,r+fit+t,-h/2,-5,10)
        frame=frame.cut(rounded_section(w+2*fit,h+2*fit,r+fit,-h/2,-6,12))
        # 全寬切除下緣 18 mm：機腹中央保持開放，避免跨過雲台。
        frame=frame.cut(box(30,w+30,80,(0,0,-h+18-40)))
        body=body.union(frame)
        for s in (-1,1):
            # 側向壓緊螺絲座，使用外部 M3 螺帽；內側配可替換止滑壓墊。
            y=s*(w/2+fit+t+1)
            boss=box(10,7,10,(0,y,-h/2))
            hole=cq.Workplane('XZ').workplane(offset=-100).center(0,-h/2).circle(1.7).extrude(200)
            body=body.union(boss).cut(hole)
            yy=s*(w/2+fit+t/2)
            # 先沿機殼側邊伸到機頭外，再向中央收攏，避免斜桿穿過機殼。
            out=c['nose_front_x']+n['front_gap']-c['nose_clamp_x']
            body=body.union(beam((0,yy,-h+23),(out,yy,-h+23),6,2.4))
            if offset:
                low=ax-RO-5
                body=body.union(beam((out,yy,-h+23),(out,offset+s*12,low),6,2.4))
                body=body.union(beam((out,offset+s*12,low),(x-RL/2+1,offset+s*12,ax-12),6,2.4))
            else:
                body=body.union(beam((out,yy,-h+23),(x-RL/2+1,s*12,ax-12),6,2.4))
        out=c['nose_front_x']+n['front_gap']-c['nose_clamp_x']
        body=body.union(beam((0,0,fit+t/2),(out,0,fit+t/2),8,2.4))
        body=body.union(beam((out,0,fit+t/2),(x-RL/2+1,offset,ax+RO-1),8,2.4))
        hardware=3.0
    else:
        pad_l=n['adhesive_pad_length']; pad_w=n['adhesive_pad_width']; pad_z=n['adhesive_thickness']+1
        for s in (-1,1):
            y=s*22
            foot=box(pad_l,pad_w,2,(0,y,pad_z)).edges('|Z').fillet(3)
            out=c['nose_front_x']+n['front_gap']-c['nose_clamp_x']
            body=body.union(foot).union(beam((pad_l/2-2,y,pad_z),(out,y,pad_z),8,2.4))
            body=body.union(beam((out,y,pad_z),(x-RL/2+1,offset+s*10,ax+RO-3),8,2.4))
        # 後側橫梁連接左右腳座，並提供獨立安全繩孔。
        body=body.union(box(6,54,2,(-pad_l/2+3,0,pad_z)))
        body=body.cut(cq.Workplane('XY').workplane(offset=-5).center(-pad_l/2+3,0).circle(1.7).extrude(20))
        hardware=2.5
    body=ring_cut(body,x,ax,offset).clean()
    return body,lens(x,ax,offset),{'position':[c['nose_clamp_x'],0,c['top_z']], 'rotation_x':0,'lens_offset_y':offset,
        'lens_axis_z':c['nose_axis_z'],'front_gap':n['front_gap'],'hardware_g':hardware,
        'pad_area_mm2':2*n['adhesive_pad_length']*n['adhesive_pad_width'] if kind=='adh' else 0}

def belly(c,kind):
    # B2 以套環／鏡組較大的外半徑 RO 計算，避免只檢核鏡筒而漏掉套環。
    contact=c['belly_z']-P['nose']['adhesive_thickness']
    stem=2 if kind=='b1' else round(max(2,contact-c['gimbal_bottom_z']+c['gimbal_clearance']-2),2)
    z=2+stem+RO
    plate=box(34,36,2,(0,0,1)).edges('|Z').fillet(5)
    tab=box(10,10,2,(-18,0,1)).edges('|Z').fillet(2)
    plate=plate.union(tab).cut(cq.Workplane('XY').center(-19,0).circle(1.7).extrude(5))
    if stem<=6:
        support=box(RL,10,stem+4,(0,0,2+(stem+2)/2))
    else:
        support=cq.Workplane('YZ').workplane(offset=-5).polyline([(-15,1.7),(15,1.7),(6,2+stem+4),(-6,2+stem+4)]).close().extrude(10)
        cut=cq.Workplane('YZ').workplane(offset=-6).polyline([(-11,5),(11,5),(2.5,stem-1),(-2.5,stem-1)]).close().extrude(12)
        support=support.cut(cut)
    body=ring_cut(plate.union(support).union(ring_blank(0,z)),0,z).clean()
    l=lens(0,z)
    bb=bbox(body.val()); lb=bbox(l.val())
    # 倒掛後，支架最高 z 變成最低點；加高至支架 ≥20 mm、鏡組 ≥30 mm。
    need=max(0,20-(contact-bb.zmax),c['lens_ground_clearance']-(contact-lb.zmax))
    extension=math.ceil(need/5)*5
    return body,l,{'position':[c['belly_x'],0,contact], 'rotation_x':math.pi,
        'stem_height':stem,'adhesive_thickness':P['nose']['adhesive_thickness'],'lens_axis_z':contact-z,'extension':extension,'hardware_g':1.5,
        'gimbal_gap':c['gimbal_bottom_z']-(contact-(z-RO)),
        'lens_ground':contact-lb.zmax+extension,'bracket_ground':contact-bb.zmax+extension}

def leg(d,E):
    ri=(d+0.6)/2; ro=ri+1.5
    body=cq.Workplane('XY').circle(ro+2).extrude(2)
    body=body.union(cq.Workplane('XY').circle(ro).extrude(E+15))
    body=body.cut(cq.Workplane('XY').workplane(offset=E).circle(ri).extrude(16))
    if E>3: body=body.cut(cq.Workplane('XY').workplane(offset=2).circle(max(2,ri-2)).extrude(E-2))
    # 束帶槽，套杯剩餘壁厚 1 mm。
    groove=cq.Workplane('XY').workplane(offset=E+9).circle(ro+1).circle(ro-0.5).extrude(2)
    return body.cut(groove).clean()

def register(key,body,print_axis=False):
    s=body.val(); solids=body.solids().size(); assert s.isValid() and solids==1, (key,'invalid or disconnected',solids)
    assert s.Volume()>0,key
    bb=bbox(s)
    STATS[key]={'valid_brep':True,'solids':solids,'volume_cm3':s.Volume()/1000,'petg_g':s.Volume()/1000*P['petg_density_g_cm3'],
                'size':[bb.xlen,bb.ylen,bb.zlen]}
    (ROOT/'STEP').mkdir(exist_ok=True); (ROOT/'STL_試裝').mkdir(exist_ok=True); (ROOT/'web').mkdir(exist_ok=True)
    cq.exporters.export(body,str(ROOT/'STEP'/f'{key}_待量測.step'))
    placed=body.rotate((0,0,0),(0,1,0),-90) if print_axis else body
    placed=placed.translate((0,0,-bbox(placed.val()).zmin))
    cq.exporters.export(placed,str(ROOT/'STL_試裝'/f'{key}_待量測.stl'),tolerance=0.025,angularTolerance=0.12)
    web=ROOT/'web'/f'{key}.stl'; cq.exporters.export(body,str(web),tolerance=0.08,angularTolerance=0.2)
    MODELS[key]=base64.b64encode(web.read_bytes()).decode('ascii')
    PRINT[key]=base64.b64encode((ROOT/'STL_試裝'/f'{key}_待量測.stl').read_bytes()).decode('ascii')
    # STEP 回讀，驗證輸出仍為有效的單一實體，且體積保持一致。
    back=cq.importers.importStep(str(ROOT/'STEP'/f'{key}_待量測.step')); reread=back.val()
    delta=abs(reread.Volume()-s.Volume())
    assert reread.isValid() and back.solids().size()==1 and delta<0.01,key
    STATS[key].update({'step_roundtrip_valid':True,'step_roundtrip_solids':back.solids().size(),'step_roundtrip_volume_delta_mm3':delta})

def main():
    for craft,c in P['crafts'].items():
        CONFIG[craft]={}
        kinds=['nose','adh']+(['b1','b2'] if craft=='m3' else [])
        for kind in kinds:
            b,l,cfg=front(c,kind) if kind in ('nose','adh') else belly(c,kind)
            key=f'{craft}_{kind}'; register(key,b,print_axis=kind in ('nose','adh'))
            # 鏡組是組立參考，不是列印零件。
            lp=ROOT/'web'/f'{key}_lens.stl'; cq.exporters.export(l,str(lp),tolerance=0.08,angularTolerance=0.2)
            MODELS[key+'_lens']=base64.b64encode(lp.read_bytes()).decode('ascii')
            cfg.update({'stl':key,'lens':key+'_lens','bracket_g':STATS[key]['petg_g']})
            if cfg.get('extension',0):
                lk=f"{craft}_leg_{cfg['extension']}"; register(lk,leg(c['leg_d'],cfg['extension']))
                cfg.update({'leg_stl':lk,'leg_g':STATS[lk]['petg_g']})
            cfg['mount_g']=cfg['bracket_g']+cfg['hardware_g']+4*cfg.get('leg_g',0)
            if kind in ('nose','adh'):
                lb=bbox(l.val()); assert abs(lb.xmin+c['nose_clamp_x']-c['nose_front_x']-P['nose']['front_gap'])<0.001,(key,lb.xmin,c['nose_clamp_x'],c['nose_front_x'])
            if kind=='b2':
                assert cfg['gimbal_gap']>=c['gimbal_clearance']-0.001
                assert cfg['lens_ground']>=c['lens_ground_clearance']-0.001 and cfg['bracket_ground']>=20-0.001
            CONFIG[craft][kind]=cfg
    data={'status':P['status'],'models':MODELS,'print_models':PRINT,'stats':STATS,'config':CONFIG,'params':P}
    (ROOT/'geometry_report.json').write_text(json.dumps({'config':CONFIG,'stats':STATS},ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT.parent/'網頁模擬'/'mounts-v6.js').write_text('window.MOUNT_V6='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')
    print(json.dumps({'config':CONFIG,'stats':STATS},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
