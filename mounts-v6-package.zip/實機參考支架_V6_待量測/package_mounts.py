from pathlib import Path
import json,zipfile,shutil,hashlib
R=Path(__file__).resolve().parent
geometry=json.loads((R/'geometry_report.json').read_text(encoding='utf-8'))
mesh=json.loads((R/'stl_check.json').read_text(encoding='utf-8'))
assert len(geometry['stats'])==7 and len(mesh)==7
lines=['# V6 產製檢核記錄','', '日期：2026-10-06。','', '本檢核只確認數位幾何與網頁功能，不確認實機適配、結構強度、黏著可靠性或飛行安全。','', '| 零件 | STEP 單一有效實體 | STEP 回讀體積差 mm³ | STL 封閉／定向 | STL 體積相對差 | PETG 實心 g |','|---|---|---:|---|---:|---:|']
for key,s in geometry['stats'].items():
    assert s['step_roundtrip_valid'] and s['step_roundtrip_solids']==1
    q=mesh[key];lines.append(f"| {key} | 通過 | {s['step_roundtrip_volume_delta_mm3']:.7f} | 通過 | {100*q['relative_brep_volume_error']:.4f}% | {s['petg_g']:.2f} |")
lines += ['', '網頁檢核：EVO 與 ALIGN 共 16 個機型／支架組合可切換；V6 方案的下載按鈕對應各自模型。ALIGN B1／B2 未再套用 EVO 的機腹尺寸。新生成幾何、STEP／STL 及下載內容共用 params.json。','', '已實際下載 ALIGN B2 STL，SHA256 與產製檔一致；所有網頁列印 STL 的 base64 內容均已與試裝 STL 逐位元比對。','', '最終 ALIGN 偏左前置夾持／黏貼兩方案，在假設雷達視錐中未見相交；槳盤水平投影仍重疊約 16 mm，鏡組與假設槳盤平面垂直相距約 30 mm，需實測動態間距及側向重心。B2 在假設下視視錐中仍有相交。','', '桌面 1280×1000 與手機 390×844 版面檢查：頁面無整體水平溢出，手機模型視距隨長寬比調整。瀏覽器未見程式錯誤。','', 'EVO 夾持版加 66 g 鏡組与估列配件後，總重約 1274.2 g，超過既有 1270 g 設定約 4.2 g；黏貼版約 1269.3 g，裕度僅約 0.7 g。以上均為體積與配件估算，須整機秤重。']
(R/'QA_幾何與網頁檢核.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
files=[]
for folder in ['STEP','STL_試裝']:
    files.extend(sorted((R/folder).glob('*')))
for name in ['README_試裝與黏貼.md','QA_幾何與網頁檢核.md','params.json','generate_mounts.py','verify_stl.py','requirements.txt','geometry_report.json','stl_check.json','ui_check.json','package_mounts.py']:
    files.append(R/name)
zip_path=R.parent/'V6_兩機型支架_STEP_STL_待量測試裝.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,Path(R.name)/p.relative_to(R))
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and sum(n.endswith('.step') for n in z.namelist())==7 and sum(n.endswith('.stl') for n in z.namelist())==7
web_zip=R.parent/'網頁模擬'/'mounts-v6-package.zip';shutil.copyfile(zip_path,web_zip)
print(json.dumps({'zip':str(zip_path),'files':len(files),'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()},ensure_ascii=False))
